from django.shortcuts import redirect
from .models import *

def Toggle(request):
    schedule = get_schedule()
    schedule.toggle()
    return redirect('index')
