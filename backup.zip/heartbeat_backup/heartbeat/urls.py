from django.conf.urls import url, include
from django.contrib import admin

urlpatterns = [
    url(r'^$',          'heartbeat.views.Index',                name='index'),
    url(r'^teams/',     include('heartbeat.teams.urls',         namespace='team')),
    url(r'^schedule/',  include('heartbeat.schedule.urls',      namespace='schedule')),
    url(r'^',           include('heartbeat.systems.urls')),
    # url(r'^',           include('heartbeat.tasks.urls')),
    url(r'^',           include('core.authentication.urls')),
    url(r'^admin/',     include(admin.site.urls)),
]