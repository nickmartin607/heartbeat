from django.contrib import admin
from .models import Check

admin.site.register(Check)