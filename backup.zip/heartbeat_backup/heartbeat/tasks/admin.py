from django.contrib import admin
from .models import Inject, Action


admin.site.register(Inject)
admin.site.register(Action)
