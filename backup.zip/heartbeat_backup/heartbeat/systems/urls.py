from django.conf.urls import url, include
from core.views import *
from .models import Host, Service
from .forms import HostForm, ServiceForm
from .views import *

service_urls = [
    url(r'^$',                          ServiceList,                                                            name='all'),
    url(r'^check/(?P<id>[0-9]+)$',      ServiceCheck,                                                           name='check'),
    url(r'^toggle/(?P<id>[0-9]+)$',     ToggleView,             {'model': Service},                             name='toggle'),
]

system_urls = [
    url(r'^$',      SystemList,          name='all'),
]

urlpatterns = [
    url(r'^systems/',                   include(system_urls,                                                   namespace='system')),
    url(r'^services/',                  include(service_urls,                                                   namespace='service')),
]